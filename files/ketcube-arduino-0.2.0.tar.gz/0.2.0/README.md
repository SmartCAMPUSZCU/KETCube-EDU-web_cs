# KETCube Arduino Core and Platform Package

## Create a package from source files

```console
$ make
```

## Tools
  * [stm32flash](https://sourceforge.net/p/stm32flash) - as the main programmer tool - see (LICENSE_STM32FLASH](LICENSE_STM32FLASH.md)
  * [PuTTY](https://www.putty.org/) - as the KETCube Terminal tool - see [LICENSE_PUTTY](LICENSE_PUTTY.md)
  * it would be more convenient to ditribute tools in separate packages, but this approach is simpler and size overhead (for duplicate platform files) is relatively small
  * on Linux, putty should be installed from the distribution repository

## Installation
  * Analogous to: [https://github.com/stm32duino/wiki/wiki/Getting-Started](https://github.com/stm32duino/wiki/wiki/Getting-Started)
  * Install [STM32CubeProgrammer](https://www.st.com/en/development-tools/stm32cubeprog.html)
