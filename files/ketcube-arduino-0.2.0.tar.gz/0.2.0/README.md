# KETCube Arduino Core and Platform Package

## Create a package from source files

```console
$ make
```

## Installation
  * Analogous to: [https://github.com/stm32duino/wiki/wiki/Getting-Started](https://github.com/stm32duino/wiki/wiki/Getting-Started)
  * Install [STM32CubeProgrammer](https://www.st.com/en/development-tools/stm32cubeprog.html)
