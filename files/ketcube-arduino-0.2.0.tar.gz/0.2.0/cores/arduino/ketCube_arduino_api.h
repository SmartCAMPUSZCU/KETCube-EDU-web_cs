/**
 * @file    ketCube_arduino_api.h
 * @author  Jan Bělohoubek
 * @version 0.2
 * @date    2020-11-30
 * @brief   This file contains API for the Arduino IDE
 * 
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 University of West Bohemia in Pilsen
 * All rights reserved.</center></h2>
 *
 * Developed by:
 * The SmartCampus Team
 * Department of Technologies and Measurement
 * www.smartcampus.cz | www.zcu.cz
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy 
 * of this software and associated documentation files (the "Software"), 
 * to deal with the Software without restriction, including without limitation 
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, 
 * and/or sell copies of the Software, and to permit persons to whom the Software 
 * is furnished to do so, subject to the following conditions:
 *
 *    - Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimers.
 *    
 *    - Redistributions in binary form must reproduce the above copyright notice, 
 *      this list of conditions and the following disclaimers in the documentation 
 *      and/or other materials provided with the distribution.
 *    
 *    - Neither the names of The SmartCampus Team, Department of Technologies and Measurement
 *      and Faculty of Electrical Engineering University of West Bohemia in Pilsen, 
 *      nor the names of its contributors may be used to endorse or promote products 
 *      derived from this Software without specific prior written permission. 
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE CONTRIBUTORS OR COPYRIGHT HOLDERS 
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS WITH THE SOFTWARE. 
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __KETCUBE_ARDUINO_API_H
#define __KETCUBE_ARDUINO_API_H

#include <stdint.h>


/** @defgroup KETCube_Arduino_API KETCube Arduino API
  * @brief KETCube Arduino API
  * @ingroup KETCube_SensMods
  * @{
  */

/** @defgroup KETCube_Arduino_API_Defines API Constants
  * @brief KETCube Arduino API Constants
  * 
  * @{
  */

#ifndef TRUE
/**
 * @brief digital PIN value
 * 
 */
typedef enum {
    TRUE  = 1,  ///< TRUE value
    FALSE = 0   ///< FALSE value
} bool_t;
#endif

/**
 * @brief Arduino PIN definition
 * 
 */
typedef enum {
    IO1 ,       ///< KETCube PIN IO1
    IO2 ,       ///< KETCube PIN IO2 
    IO3 ,       ///< KETCube PIN IO3 
    IO4 ,       ///< KETCube PIN IO4 
    AN  ,       ///< KETCube PIN AN  
    RST ,       ///< KETCube PIN RST 
    CS  ,       ///< KETCube PIN CS  
    SCK ,       ///< KETCube PIN SCK 
    MISO,       ///< KETCube PIN MISO
    MOSI,       ///< KETCube PIN MOSI
    PWM ,       ///< KETCube PIN PWM 
    INT ,       ///< KETCube PIN INT 
    RX  ,       ///< KETCube PIN RX  
    TX  ,       ///< KETCube PIN TX  
    SCL ,       ///< KETCube PIN SCL 
    SDA ,       ///< KETCube PIN SDA 
    LED1,       ///< KETCube PIN LED1
    LED2,       ///< KETCube PIN LED2
} ketCube_Arduino_pin_t;

/**
 * @brief digital PIN mode
 * 
 */
typedef enum {
    OUTPUT,         ///< PIN mode OUTPUT
    INPUT,          ///< PIN mode INPUT
    INPUT_PULLUP,   ///< PIN mode INPUT with PULL UP
    INPUT_PULLDOWN  ///< PIN mode INPUT with PULL DOWN
} ketCube_Arduino_pinMode_t;

/**
 * @brief digital PIN value
 * 
 */
typedef enum {
    HIGH = TRUE,   ///< PIN value HIGH
    LOW = FALSE    ///< PIN value LOW
} ketCube_Arduino_pinValue_t;

/**
* @brief LED functions
*/
typedef enum {
    LED_OFF = 0,        ///< LED is permanently OFF  
    LED_ON,             ///< LED is permanently ON 
    LED_BLINK_SINGLE,   ///< LED BLINKs - single flash
    LED_BLINK_CONT      ///< LED BLINKs - continuous flashing
} ketCube_Arduino_ledFunction_t;

/**
* @}
*/

typedef void (*IO_pinMode_t)(ketCube_Arduino_pin_t, ketCube_Arduino_pinMode_t);
typedef void (*IO_digitalWrite_t)(ketCube_Arduino_pin_t, ketCube_Arduino_pinValue_t);
typedef ketCube_Arduino_pinValue_t (*IO_digitalRead_t)(ketCube_Arduino_pin_t);

typedef void (*LED_init_t)(ketCube_Arduino_pin_t, ketCube_Arduino_pinValue_t);
typedef void (*LED_set_t)(ketCube_Arduino_pin_t, ketCube_Arduino_ledFunction_t);

typedef void (*Terminal_print_t)(char *, ...);
typedef void (*Terminal_printError_t)(char *, ...);
typedef void (*Terminal_printInfo_t)(char *, ...);
typedef void (*Terminal_printDebug_t)(char *, ...);

typedef void (*Time_delay_t)(uint32_t);
typedef void (*Time_delayMicroseconds_t)(uint32_t);
typedef uint32_t (*Time_micros_t)(void);
typedef uint32_t (*Time_millis_t)(void);

/**
 * @brief KETCube API object
 * 
 */
typedef struct ketCube_Arduino_API_t {   
   /**
    * @brief KETCube Arduino Digital IO API
    * 
    */
    struct IO {       
        /**
         * @brief Configures the specified pin to behave either as an input or an output
         * 
         * @param pin digital PIN, @ref ketCube_Arduino_pin_t
         * @param pinMode @ref ketCube_Arduino_pinMode_t
         * 
         */
        IO_pinMode_t pinMode;
        
        /**
         * @brief Write a value to a digital pin
         * 
         * @param pin digital PIN, @ref ketCube_Arduino_pin_t
         * @param pinValue HIGH or LOW value, @ref ketCube_Arduino_pinValue_t
         * 
         */
        IO_digitalWrite_t digitalWrite;
        
        /**
         * @brief Reads the value from a specified digital pin
         *
         * @param pin digital PIN, @ref ketCube_Arduino_pin_t
         * @retval pinValue HIGH or LOW value, @ref ketCube_Arduino_pinValue_t
         * 
         */
        IO_digitalRead_t digitalRead;
    } IO;
    
    /**
    * @brief KETCube Arduino LED Driver API
    * 
    */
    struct LED {       
        /**
         * @brief Configures the specified pin as the LED driver
         * 
         * @param pin digital PIN, @ref ketCube_Arduino_pin_t
         * @param polarity value to turn LED ON @ref ketCube_Arduino_pinValue_t
         * 
         */
        LED_init_t init;
        
        /**
         * @brief Configures the LED function
         * 
         * @param pin digital PIN, @ref ketCube_Arduino_pin_t
         * @param LEDFunction LED blink function @ref ketCube_Arduino_ledFunction_t
         * 
         */
        LED_set_t set;
        
    } LED;

    /**
    * @brief KETCube Terminal Arduino API
    * 
    */
    struct Terminal {
        /**
         * @brief Sends formatted output to KETCube terminal 
         * 
         * Behaves similarly to the C printf function
         * the String is prefixed by the module prefix string ("Arduino :: ") and terminated by the new line
         * 
         * @param format string that contains the text to be written to stdout. It can optionally contain embedded format tags that are replaced by the values specified in subsequent additional arguments -- @see https://sourceware.org/newlib/libc.html#sprintf
         * @param args additional arguments depending on the format string
         * 
         */
        Terminal_print_t      print;
        
        /**
         * @brief Sends formatted output to KETCube terminal 
         * 
         * Behaves similarly to the C printf function
         * the String is prefixed by the module prefix string ("Arduino :: ") and terminated by the new line
         * 
         * @note the string is produced only if Arduino module severity is set to 1 (ERROR)
         * 
         * @param format string that contains the text to be written to stdout. It can optionally contain embedded format tags that are replaced by the values specified in subsequent additional arguments -- @see https://sourceware.org/newlib/libc.html#sprintf
         * @param args additional arguments depending on the format string
         * 
         */
        Terminal_printError_t printError;
        
        /**
         * @brief Sends formatted output to KETCube terminal 
         * 
         * Behaves similarly to the C printf function
         * the String is prefixed by the module prefix string ("Arduino :: ") and terminated by the new line
         * 
         * @note the string is produced only if Arduino module severity is set to 2 (INFO)
         * 
         * @param format string that contains the text to be written to stdout. It can optionally contain embedded format tags that are replaced by the values specified in subsequent additional arguments -- @see https://sourceware.org/newlib/libc.html#sprintf
         * @param args additional arguments depending on the format string
         * 
         */
        Terminal_printInfo_t  printInfo;
        
        /**
         * @brief Sends formatted output to KETCube terminal 
         * 
         * Behaves similarly to the C printf function
         * the String is prefixed by the module prefix string ("Arduino :: ") and terminated by the new line
         * 
         * @note the string is produced only if Arduino module severity is set to 3 (DEBUG)
         * 
         * @param format string that contains the text to be written to stdout. It can optionally contain embedded format tags that are replaced by the values specified in subsequent additional arguments -- @see https://sourceware.org/newlib/libc.html#sprintf
         * @param args additional arguments depending on the format string
         * 
         */
        Terminal_printDebug_t printDebug;
    } Terminal;
    
    /**
    * @brief KETCube Arduino Time API
    * 
    */
    struct Time {
        /**
         * @brief Pauses the program for the amount of time (in milliseconds)
         *
         * @param ms the number of milliseconds to pause
         * 
         */
        Time_delay_t delay;
        
        /**
         * @brief Pauses the program for the amount of time (in microseconds)
         *
         * @param us the number of microseconds to pause
         * 
         */
        Time_delayMicroseconds_t delayMicroseconds;
        
        /**
         * @brief Get the number of microseconds since last KETCube PoR or overflow
         *
         * @retval ms the number of microseconds since last KETCube PoR or overflow
         * 
         */
        Time_micros_t micros;
        
        /**
         * @brief Get the number of milliseconds since last KETCube PoR
         *
         * @retval ms the number of milliseconds since last KETCube PoR
         * 
         */
        Time_millis_t millis;
    } Time;
} ketCube_Arduino_API_t;


extern ketCube_Arduino_API_t KETCube;

/**
* @}
*/

#endif                          /* __KETCUBE_ARDUINO_API_H */
