# KETCube Arduino Core and Platform Package
  * KETCube Arduino package source resides here

## Create a Package From Source Files
  * target package and json metadata will be henerated from source in ./build
  * also the Arduino library with examples is generated
  
```console
$ make
```

## Tools
  * [stm32flash](https://sourceforge.net/p/stm32flash) - as the main programmer tool - see (LICENSE_STM32FLASH](LICENSE_STM32FLASH.md)
  * [PuTTY](https://www.putty.org/) - as the KETCube Terminal tool - see [LICENSE_PUTTY](LICENSE_PUTTY.md)
  * it would be more convenient to ditribute tools in separate packages, but this approach is simpler and size overhead (for duplicate platform files) is relatively small
  * on the Linux target, PuTTY should be installed from the distribution repository

## Installation
  * Analogous to: [https://github.com/stm32duino/wiki/wiki/Getting-Started](https://github.com/stm32duino/wiki/wiki/Getting-Started)
  * Install [STM32CubeProgrammer](https://www.st.com/en/development-tools/stm32cubeprog.html)
