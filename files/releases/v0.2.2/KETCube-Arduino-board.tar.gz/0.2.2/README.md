# KETCube Arduino Core and Platform Package
  * KETCube Arduino package source resides here

## Create a New Package(s) From Source Files
  * target package and json metadata will be henerated from source in ./build
  * also the Arduino library with examples is generated
  
```console
$ make clean
$ make
```

  * create a new [release](https://github.com/SmartCAMPUSZCU/KETCube-arduino/releases/)
  * create this tag: v[VERSION] (as used in generated json file) and upload generated library, pakage and json file
  * the webpage links automatically point to the latest release
  * update the repository at the webpage, as described below

## Update Repository
  * to update package_ketcube_index.json located at the webpage (the "master location"), from the generated one, **!!! add only the version-speciffic part !!!**
  * retain old versions @master location - otherwise, upgrade issues may arise, when users have older package version installed
  * upload new package to: https://edu.ketcube.cz/files/releases/v[VERSION]/[FILENAME]"
    * this is due to error when downloading directly from github releases - redirect causes error in Arduino IDE

## Tools
  * [stm32flash](https://sourceforge.net/p/stm32flash) - as the main programmer tool - see (LICENSE_STM32FLASH](LICENSE_STM32FLASH.md)
  * [PuTTY](https://www.putty.org/) - as the KETCube Terminal tool - see [LICENSE_PUTTY](LICENSE_PUTTY.md)
  * it would be more convenient to ditribute tools in separate packages, but this approach is simpler and size overhead (for duplicate platform files) is relatively small
  * on the Linux target, PuTTY should be installed from the distribution repository

## Installation
  * Analogous to: [https://github.com/stm32duino/wiki/wiki/Getting-Started](https://github.com/stm32duino/wiki/wiki/Getting-Started)
  * Optionally Install [STM32CubeProgrammer](https://www.st.com/en/development-tools/stm32cubeprog.html) (when you require STM32 Tools)
